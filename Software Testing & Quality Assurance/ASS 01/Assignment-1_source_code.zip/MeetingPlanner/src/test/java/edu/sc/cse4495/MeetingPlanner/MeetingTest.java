package edu.sc.cse4495.MeetingPlanner;

public class MeetingTest {
	// Add test methods here. 
    // You are not required to write tests for all classes.
}
